const LocalStrategy = require('passport-local').Strategy;
const Passport = require('passport');
const User = require('./models/User.js');

//---------------------------------------------------------------------------------------------

module.exports = function(pPassport) {
    pPassport.use(
        new LocalStrategy({ usernameField: 'email'}, (sEmail, sPassword, pNext) => {
            User.prototype.emailExists(sEmail, function(bExists) {
                if (!bExists) { // Account doesnt exist.
                    return pNext(null, false, { message: 'The email entered is not registered to any account.' })
                }

                User.prototype.login(sEmail, sPassword, function(pUser) {
                    if (pUser != null) { // Login successful.
                        return pNext(null, pUser);
                    } else {
                        return pNext(null, false, { message: 'The password entered is incorrect for that account.' })
                    }
                })
            })
        })
    );
}

//---------------------------------------------------------------------------------------------

Passport.serializeUser(function(pUser, pDone) {
    pDone(null, pUser.sEmail); 
});

Passport.deserializeUser(function(sEmail, pDone) {
    User.prototype.find(sEmail, function(pUser) {
        pDone(null, pUser);
    });
});

//---------------------------------------------------------------------------------------------
