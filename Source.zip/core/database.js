const Util = require('util');
const MySQL = require('mysql');

//---------------------------------------------------------------------------------------------

const DATABASE_HOST='localhost';
const DATABASE_PORT=8889;
const DATABASE_USER='root';
const DATABASE_PASSWORD='root';
const DATABASE_SCHEMA='ontechu_bookstore';

const pConnectionPool = MySQL.createPool({
    connectionLimit: 10,
    host: DATABASE_HOST,
    port: DATABASE_PORT,
    user: DATABASE_USER, 
    password: DATABASE_PASSWORD, 
    database: DATABASE_SCHEMA
});

pConnectionPool.getConnection((pError, pConnection) => {
    if(pError) 
        console.error(" -> Unable to Establish Database Connection");
    else
        console.error(" -> Database Connection Established");

    if(pConnection)
        pConnection.release();

    return;
});

pConnectionPool.query = Util.promisify(pConnectionPool.query);

//---------------------------------------------------------------------------------------------

module.exports = pConnectionPool;

//---------------------------------------------------------------------------------------------