module.exports = {
    
    enforceAuth : function(pReq, pRes, pNext) {

        if (pReq.isAuthenticated()) {
            return pNext();
        }
        pReq.flash('ErrorMessage', 'You must be logged in to view this resource.');
        pRes.redirect('/auth/login');
    },

    rejectAuth : function(pReq, pRes, pNext) {

        if (!pReq.isAuthenticated()) {
            return pNext();
        }
        pRes.redirect('/dashboard');
    }
}