const Database = require('../database.js');

//---------------------------------------------------------------------------------------------

function Book() {

};

function Book(pDataResult) {
    if (pDataResult != null) {
        this.nBookID = pDataResult.book_id;
        this.sName = pDataResult.name;
        this.sAuthors = pDataResult.authors;
        this.sCourseID = pDataResult.course_id;
        this.nCost = pDataResult.cost;
        this.nStock = pDataResult.stock;
        this.nAvailabilityType = pDataResult.availability_type;
    }
}

//---------------------------------------------------------------------------------------------

Book.prototype = {

    nBookID             : 0,      // Book ID                : Integer
    sName               : '0',    // Book Name              : String
    sAuthors            : '0',    // Author Names           : String
    sCourseID           : '0',    // Assosciated Course ID  : String
    nCost               : '0',    // Cost                   : Integer
    nStock              : '0',    // Stock                  : String
    nAvailabilityType   : '0',    // Availibility Type      : Integer

    //---------------------------------------------------------------------------------------------

    /**
     * 
     * @param {Integer} nBookID 
     */
    find : function(nBookID, pCallback) {

        let sSQL = `SELECT * FROM books WHERE book_id = ?`;
        Database.query(sSQL, nBookID, function(pError, pResult) {
            if(pError) throw pError

            if(pResult.length > 0) {
                var pBook = new Book(pResult[0]);
                pCallback(pBook);
            } else {
                pCallback(null);
            }
        });
    },

    //---------------------------------------------------------------------------------------------

    getForCourse : function(sCourseID, pCallback) {

        let sSQL = `SELECT * FROM books WHERE course_id = ?`;
        Database.query(sSQL, sCourseID, function(pError, pResult) {
            if(pError) throw pError
            
            let aBooks = [];
            for(var i = 0; i < pResult.length; i++) {
                aBooks.push(new Book(pResult[i]));
            }
            pCallback(aBooks);
        });
    },

    getForEnrollment : function(nStudentID, pCallback) {
        let sSQL = `SELECT * FROM books WHERE course_id IN (SELECT course_id FROM enrolled WHERE student_id = ?)`;
        Database.query(sSQL, nStudentID, function(pError, pResult) {
            if(pError) throw pError
            
            let aBooks = [];
            for(var i = 0; i < pResult.length; i++) {
                aBooks.push(new Book(pResult[i]));
            }
            pCallback(aBooks);
        });
    },

    getAll : function(pCallback) {

        let sSQL = `SELECT * FROM books`;
        Database.query(sSQL, function(pError, pResult) {
            if(pError) throw pError
            
            let aBooks = [];
            for(var i = 0; i < pResult.length; i++) {
                aBooks.push(new Book(pResult[i]));
            }
            pCallback(aBooks);
        });
    },

    searchBook : function(sSearch, pCallback) {
        let sSQL = `SELECT * FROM books WHERE name LIKE '%` + sSearch + `%' OR course_id LIKE '%` + sSearch + `%'`;
        Database.query(sSQL, function(pError, pResult) {
            if(pError) throw pError
            
            let aBooks = [];
            for(var i = 0; i < pResult.length; i++) {
                aBooks.push(new Book(pResult[i]));
            }
            pCallback(aBooks);
        });
    },

    //---------------------------------------------------------------------------------------------

    increaseStock : function(nBookID) {

        this.find(nBookID, function(pBook) {
            var bPDF = pBook.nAvailabilityType == 1;
            if (!bPDF) {
                let sSQL = `UPDATE books SET stock = (stock + 1) WHERE book_id = ?`;
                Database.query(sSQL, nBookID, function(pError, pResult) {
                    if(pError) throw pError

                    return true;
                });
            }
        });
        return false;
    },

    decreaseStock : function(nBookID) {

        this.find(nBookID, function(pBook) {
            var bPDF = pBook.nAvailabilityType == 1;
            if (!bPDF) {
                let sSQL = `UPDATE books SET stock = (stock - 1) WHERE book_id = ?`;
                Database.query(sSQL, nBookID, function(pError, pResult) {
                    if(pError) throw pError

                    return true;
                });
            }
        });
        return false;
    },
    
}

//---------------------------------------------------------------------------------------------

module.exports = Book;

//---------------------------------------------------------------------------------------------