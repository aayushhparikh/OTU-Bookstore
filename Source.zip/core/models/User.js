const Database = require('../database.js');
const Argon2 = require('argon2');

const Course = require('./Course.js');
const Order = require('./Order.js');
const Book = require('./Book.js');

//---------------------------------------------------------------------------------------------

function User() {

};

function User(pDataResult) {
    if (pDataResult != null) {
        this.nStudentID = pDataResult.student_id;
        this.sEmail = pDataResult.email;
        this.sPassword = pDataResult.password;
        this.sFirstName = pDataResult.first_name;
        this.sLastName = pDataResult.last_name;
        this.sAddress = pDataResult.address;
        this.sPostalCode = pDataResult.postal_code;
        this.sPhone = pDataResult.phone_number;
        this.sBirthday = pDataResult.birthday;
        this.nProgramID = pDataResult.program;
    }
}

//---------------------------------------------------------------------------------------------

User.prototype = {

    nID          : 0,
    nStudentID   : 0,    // Student ID                   : Integer
    nProgramID   : 0,    // University Progam ID         : Integer

    sEmail       : "",   // OntarioTech Email Address    : String
    sPassword    : "",   // Hashed Password              : String 

    sFirstName   : "",   // Legal First Name             : String
    sLastName    : "",   // Legal Last Name              : String
    sAddress     : "",   // Home Address                 : String
    sPostalCode  : "",   // Address Postal Code          : String
    sPhone       : "",   // Primary Phone Number         : String
    sBirthday    : "",   // Date of Birth                : Date

    //---------------------------------------------------------------------------------------------

    /**
     * 
     * @param {String} sEmail 
     */
    find : function(sEmail, pCallback) {

        let sSQL = `SELECT * FROM users WHERE email = ?`;
        Database.query(sSQL, sEmail, function(pError, pResult) {
            if(pError) throw err

            if(pResult.length > 0) {
                var pUser = new User(pResult[0]);
                pCallback(pUser);
            } else {
                pCallback(null);
            }
        });
    },

    //---------------------------------------------------------------------------------------------

    /**
     * Check if an email is used on an existing account.
     * @param {String} sEmail 
     */
    emailExists : function(sEmail, pCallback) {
        this.find(sEmail, function(pUser) {
            var bExists = pUser != null; 
            pCallback(bExists);  
        });
    },

    /**
     * Create a new account and return true or false depending on if the account was created.
     * @param {String} sEmail 
     * @param {String} sPassword 
     */
    register : function(sEmail, sPassword) {

        try {

            Argon2.hash(sPassword).then(hashedPassword => {
                var pUser = new User();
                pUser.sEmail = sEmail;
                pUser.sPassword = hashedPassword;
                pUser.loadStudentInformation();
    
                let sSQL = `INSERT INTO users(student_id, email, password, first_name, last_name, address, postal_code, phone_number, birthday, program) VALUES (DEFAULT, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
                let sInsertData = [pUser.sEmail, pUser.sPassword, pUser.sFirstName, pUser.sLastName, pUser.sAddress, pUser.sPostalCode, pUser.sPhone, null, pUser.nProgramID];
    
                Database.query(sSQL, sInsertData, function(pError, pResult) { // Call the query an pass insert data as array of parameters.
                    if(pError) throw pError;
                    User.prototype.enrollCourses(pUser.sEmail);
                    return true; // Account was created successfully.
                });
            });

        } catch (pError) {
            throw pError;
        }
        return false; // Something went wrong.
    },

    /**
     * Attempt to login to an account by verifying email and password, return the user object if successful.
     * @param {String} sEmail 
     * @param {String} sPassword 
     */
    login : function(sEmail, sPassword, pCallback) {

        this.find(sEmail, function(pUser) {
            if (pUser != null) {
                Argon2.verify(pUser.sPassword, sPassword).then(bSuccess => {
                    if (bSuccess) {
                        pCallback(pUser);
                    } else {
                        pCallback(null);
                    }
                }).catch(pError => {
                    if(pError) pCallback(null);
                });
            }
        });
    },

    //---------------------------------------------------------------------------------------------

    /**
     * Load the most up to date information for the student from the Ontario Tech University API.
     */
    loadStudentInformation : function() {

        this.sFirstName = "John";
        this.sLastName = "Doe";
        this.sAddress = "2000 Simcoe St. North";
        this.sPostalCode = "L1L 1L1";
        this.sPhone = "416-888-2222";
        this.sBirthday = "January 1st, 2020";
        this.nProgramID = 1;

    },

    enrollCourses : function(sEmail) {
        User.prototype.find(sEmail, function(pUser) {

            if (pUser != null) {
                let sSQL = `INSERT INTO enrolled(enrollment_id, student_id, course_id) VALUES (DEFAULT, ?, ?)`;
                let sInsertData = [pUser.nStudentID, "SOFE3770"];
                Database.query(sSQL, sInsertData, function(pError, pResult) {});

                sSQL = `INSERT INTO enrolled(enrollment_id, student_id, course_id) VALUES (DEFAULT, ?, ?)`;
                sInsertData = [pUser.nStudentID, "PHY1010"];
                Database.query(sSQL, sInsertData, function(pError, pResult) {});

                sSQL = `INSERT INTO enrolled(enrollment_id, student_id, course_id) VALUES (DEFAULT, ?, ?)`;
                sInsertData = [pUser.nStudentID, "MATH1010"];
                Database.query(sSQL, sInsertData, function(pError, pResult) {});
            }
        })
    },
    
    //---------------------------------------------------------------------------------------------

    /**
     * 
     * @param {String} sEmail 
     */
    getEnrolledCourses : function(nStudentID, pCallback) {
        
        let sSQL = `SELECT * FROM courses WHERE course_id IN (SELECT course_id FROM enrolled WHERE student_id = ?)`;
        Database.query(sSQL, nStudentID, function(pError, pResult) {
            if(pError) throw pError

            if (pResult.length > 0) {
                let aCourse = [];
                for(var i = 0; i < pResult.length; i++) {
                    aCourse.push(new Course(pResult[i]));
                }
                pCallback(aCourse);
            } else { 
                pCallback(null);
            }
        });
    },

    getOrders : function(nStudentID, bActive, bArchived, pCallback) {
        
        let sSQL = `SELECT o.*, b.name, b.availability_type FROM orders o LEFT JOIN books b ON o.book_id = b.book_id WHERE`;
        if (nStudentID >= 0) {
            sSQL += ` o.student_id = ?`;
        } else {
            sSQL += ` o.student_id > 0`;
        }
        
        if (bActive && !bArchived) {
            sSQL += ` AND status = 0`;
        } else if (!bActive && bArchived) {
            sSQL += ` AND (status = 1 OR status = -1)`;
        }
        Database.query(sSQL, nStudentID, function(pError, pResult) {
            if(pError) throw pError

            if (pResult.length > 0) {
                let aOrders = [];
                for(var i = 0; i < pResult.length; i++) {
                    aOrders.push(new Order(pResult[i]));
                }
                pCallback(aOrders);
            } else { 
                pCallback(null);
            }
        });
    },

    placeOrder : function(pOrder) {

        let sSQL = `INSERT INTO orders(order_id, book_id, student_id, quantity, total_due, pick_up_time, status) VALUES (DEFAULT, ?, ?, ?, ?, ?, ?)`;
        let sInsertData = [pOrder.nBookID, pOrder.nStudentID, pOrder.nQuantity, pOrder.nTotalCostDue * 1.13, pOrder.tPickUp, pOrder.nStatus];
    
        Database.query(sSQL, sInsertData, function(pError, pResult) {
            if(pError) throw pError

            Book.prototype.decreaseStock(pOrder.nBookID);
            return true;
        });
        return false;
    },

    cancelOrder : function(pOrder) {

        let sSQL = `UPDATE orders SET status = -1 WHERE order_id = ? AND student_id = ?`;
        let sInsertData = [pOrder.nOrderID, pOrder.nStudentID];
    
        Database.query(sSQL, sInsertData, function(pError, pResult) {
            if(pError) throw pError

            Book.prototype.increaseStock(pOrder.nBookID);
            return true;
        });
        return false;
    },

    confirmOrder : function(pOrder) {

        let sSQL = `UPDATE orders SET status = 1 WHERE order_id = ? AND student_id = ?`;
        let sInsertData = [pOrder.nOrderID, pOrder.nStudentID];
    
        Database.query(sSQL, sInsertData, function(pError, pResult) {
            if(pError) throw pError

            Book.prototype.increaseStock(pOrder.nBookID);
            return true;
        });
        return false;
    },

}

//---------------------------------------------------------------------------------------------

module.exports = User;

//---------------------------------------------------------------------------------------------