const Database = require('../database.js');

//---------------------------------------------------------------------------------------------

function Order() {

};

function Order(pDataResult) {
    if (pDataResult != null) {
        this.nOrderID = pDataResult.order_id;
        this.nStudentID = pDataResult.student_id;
        this.nBookID = pDataResult.book_id;
        this.nQuantity = pDataResult.quantity;
        this.nTotalCostDue = pDataResult.total_due;
        this.tPickUp = pDataResult.pick_up_time;
        this.nStatus = pDataResult.status;
        if (pDataResult.name != null) {
            this.sBookName = pDataResult.name;
        }
        if (pDataResult.availability_type != null) {
            this.bPDF = pDataResult.availability_type == 1;
        } 
    }
}

//---------------------------------------------------------------------------------------------

Order.prototype = {

    nOrderID        : 0,      // Order ID           : Integer
    nStudentID      : '0',    // Student ID         : String
    nBookID         : '0',    // Book ID            : String
    nQuantity       : '0',    // Order Quantity     : String
    nTotalCostDue   : '0',    // Total Due          : Integer
    tPickUp         : '0',    // Pick Up Time       : String
    nStatus         : '0',    // Order Status       : Integer

    sBookName       : '0',    // Book Name          : String
    bPDF            : false,  // PDF                : Boolean

    //---------------------------------------------------------------------------------------------

    /**
     * 
     * @param {Integer} nOrderID 
     */
    find : function(nOrderID, pCallback) {

        let sSQL = `SELECT * FROM orders WHERE order_id = ?`;
        Database.query(sSQL, nOrderID, function(pError, pResult) {
            if(pError) throw pError

            if(pResult.length > 0) {
                var pOrder = new Order(pResult[0]);
                pCallback(pOrder);
            } else {
                pCallback(null);
            }
        });
    },

    getOrders : function(nStudentID, bActive, bArchived, pCallback) {
        
        let sSQL = `SELECT o.*, b.name, b.availability_type FROM orders o LEFT JOIN books b ON o.book_id = b.book_id WHERE o.student_id = ?`;
        if (bActive && !bArchived) {
            sSQL += ` AND status = 0`;
        } else if (!bActive && bArchived) {
            sSQL += ` AND (status = 1 OR status = -1)`;
        }
        Database.query(sSQL, nStudentID, function(pError, pResult) {
            if(pError) throw pError

            if (pResult.length > 0) {
                let aOrders = [];
                for(var i = 0; i < pResult.length; i++) {
                    aOrders.push(new Order(pResult[i]));
                }
                pCallback(aOrders);
            } else { 
                pCallback(null);
            }
        });
    },
    
}

//---------------------------------------------------------------------------------------------

module.exports = Order;

//---------------------------------------------------------------------------------------------