const Database = require('../database.js');

//---------------------------------------------------------------------------------------------

function Course() {

};

function Course(pDataResult) {
    if (pDataResult != null) {
        this.sCourseID = pDataResult.course_id;
        this.sName = pDataResult.name;
    }
}

//---------------------------------------------------------------------------------------------

Course.prototype = {

    sCourseID   : 0,      // Course ID              : Integer
    sName       : '0',    // Course Name            : String

    //---------------------------------------------------------------------------------------------

    /**
     * 
     * @param {Integer} sCourseID 
     */
    find : function(sCourseID, pCallback) {

        let sSQL = `SELECT * FROM courses WHERE course_id = ?`;
        Database.query(sSQL, sCourseID, function(pError, pResult) {
            if(pError) throw err

            if(pResult.length > 0) {
                var pCourse = new Course(pResult[0]);
                pCallback(pCourse);
            } else {
                pCallback(null);
            }
        });
    },
    
    getAll : function(pCallback) {

        let sSQL = `SELECT * FROM courses`;
        Database.query(sSQL, function(pError, pResult) {
            if(pError) throw err
            
            let aCourse = [];
            for(var i = 0; i < pResult.length; i++) {
                aCourse.push(new Course(pResult[i]));
            }
            pCallback(aCourse);
        });
    },
}

//---------------------------------------------------------------------------------------------

module.exports = Course;

//---------------------------------------------------------------------------------------------