const User = require('./models/User');
const Course = require('./models/Course');
const Book = require('./models/Book');
const Order = require('./models/Order');

//---------------------------------------------------------------------------------------------

module.exports = {
    
    sendUserData : function(sEmail, pOut) {

        User.prototype.find(sEmail, function(pUser) {
            if (pUser != null) {
                pOut.json(
                    {
                        student_id : pUser.nStudentID,
                        first_name : pUser.sFirstName,
                        last_name : pUser.sLastName,
                        email : pUser.sEmail,
                        address : pUser.sAddress,
                        postal_code : pUser.sPostalCode,
                        phone_number : pUser.sPhone,
                        birthday : pUser.sBirthday,
                        program_id : pUser.nProgramID,
                    }
                );
            } else {
                pOut.json({});
            }
        });
    },

    sendUserList : function(pOut) {

        pOut.json({});
    },

    //---------------------------------------------------------------------------------------------

    sendCourseEnrollmentData : function(sCourseID, pOut) {

        pOut.json({});
    },

    sendUserEnrollmentData : function(nStudentID, pOut) {

        User.prototype.getEnrolledCourses(nStudentID, function(aCourse) {

            const aData = {
                headers: ["Course ID", "Course Name", ""],
                rows: new Array(),
            }

            if (aCourse != null) {
                aCourse.forEach(pCourse => {
                    var sButton = `<a href="/store/${pCourse.sCourseID}" class="theme-btn theme-btn-primary">Browse Books</a>`;
                    aData.rows.push([pCourse.sCourseID, pCourse.sName, sButton]);
                });
            }
            
            pOut.json(aData);
        });
    },

    //---------------------------------------------------------------------------------------------

    sendBookData : function(nBookID, pOut) {

        Book.prototype.find(nBookID, function(pBook) {

            const aData = {
                objects: new Array(),
            }
            if (pBook != null) {
                aData.objects.push(pBook);
            }
            pOut.json(aData);
        });
    },

    sendBookList : function(pOut) {

        Book.prototype.getAll(function(aBooks) {

            const aData = {
                headers: ["Book ID", "Book Name", "Authors", "Course", "Cost", "Stock", "Availability"],
                rows: new Array(),
                objects: new Array(),
            }

            if (aBooks != null) {
                aBooks.forEach(pBook => {
                    aData.rows.push([pBook.nBookID, pBook.sName, pBook.sAuthors, pBook.sCourseID, pBook.nCost, pBook.nStock, pBook.nAvailabilityType]);
                    aData.objects.push(pBook);
                });
            }
            
            pOut.json(aData);
        });
    },

    sendBookSearch : function(sSearch, pOut) {

        Book.prototype.searchBook(sSearch, function(aBooks) {

            const aData = {
                headers: ["Book ID", "Book Name", "Authors", "Course", "Cost", "Stock", "Availability"],
                rows: new Array(),
                objects: new Array(),
            }

            if (aBooks != null) {
                aBooks.forEach(pBook => {
                    aData.rows.push([pBook.nBookID, pBook.sName, pBook.sAuthors, pBook.sCourseID, pBook.nCost, pBook.nStock, pBook.nAvailabilityType]);
                    aData.objects.push(pBook);
                });
            }
            
            pOut.json(aData);
        });
    },

    sendEnrolledBookList : function(nStudentID, pOut) {

        Book.prototype.getForEnrollment(nStudentID, function(aBooks) {

            const aData = {
                headers: ["Book ID", "Book Name", "Authors", "Course", "Cost", "Stock", "Availability"],
                rows: new Array(),
                objects: new Array(),
            }

            if (aBooks != null) {
                aBooks.forEach(pBook => {
                    aData.rows.push([pBook.nBookID, pBook.sName, pBook.sAuthors, pBook.sCourseID, pBook.nCost, pBook.nStock, pBook.nAvailabilityType]);
                    aData.objects.push(pBook);
                });
            }
            
            pOut.json(aData);
        });
    },

    sendCourseBookList : function(sCourseID, pOut) {

        Book.prototype.getForCourse(sCourseID, function(aBooks) {

            const aData = {
                headers: ["Book ID", "Book Name", "Authors", "Course", "Cost", "Stock", "Availability"],
                rows: new Array(),
                objects: new Array(),
            }

            if (aBooks != null) {
                aBooks.forEach(pBook => {
                    aData.rows.push([pBook.nBookID, pBook.sName, pBook.sAuthors, pBook.sCourseID, pBook.nCost, pBook.nStock, pBook.nAvailabilityType]);
                    aData.objects.push(pBook);
                });
            }
            
            pOut.json(aData);
        });
    },

    //---------------------------------------------------------------------------------------------

    sendOrderData : function(sCourseID, pOut) {

        pOut.json({});
    },

    sendManageOrders : function(nStudentID, bActive, bArchived, pOut) {

        User.prototype.getOrders(nStudentID, bActive, bArchived, function(aOrders) {

            const aData = {
                headers: ["ID", "Book", "Cost", "Pick Up", "Student ID", "Status", ""],
                rows: new Array(),
                objects: new Array(),
            }

            if (aOrders != null) {
                aOrders.forEach(pOrder => {

                    var sStatus = `<a href="/order/cancel/${pOrder.nOrderID}" class="theme-btn-min theme-btn-primary">Active</a>`;
                    if (pOrder.nStatus == -1) {
                        sStatus = `<a href="#" class="theme-btn-min theme-btn-primary">Cancelled</a>`;
                    } else if (pOrder.nStatus == 1) {
                        sStatus = `<a href="#" class="theme-btn-min theme-btn-primary">Completed</a>`;
                    }

                    var sButton = `<a href="/admin/order/cancel/${pOrder.nOrderID}" class="theme-btn-min theme-btn-secondary mr-2">Cancel</a><a href="/admin/order/confirm/${pOrder.nOrderID}" class="theme-btn-min theme-btn-secondary">Confirm</a>`;
                    if (pOrder.nStatus == -1 || pOrder.nStatus == 1) {
                        sButton = ``;
                    } 
                    var sPickUp = new Date(pOrder.tPickUp).toLocaleString();
                    if (pOrder.bPDF) {
                        sPickUp = "PDF";
                    }
                    aData.rows.push([pOrder.nOrderID, pOrder.sBookName, '$' + pOrder.nTotalCostDue, sPickUp, pOrder.nStudentID, sStatus, sButton]);
                    aData.objects.push(pOrder);
                });
            }
            
            pOut.json(aData);
        });
    },

    sendOrders : function(nStudentID, bActive, bArchived, pOut) {

        User.prototype.getOrders(nStudentID, bActive, bArchived, function(aOrders) {

            const aData = {
                headers: ["ID", "Book", "Cost", "Pick Up", ""],
                rows: new Array(),
                objects: new Array(),
            }

            if (aOrders != null) {
                aOrders.forEach(pOrder => {
                    var sButton = `<a href="/store/order/cancel/${pOrder.nOrderID}" class="theme-btn-min theme-btn-secondary">Cancel</a>`;
                    if (pOrder.nStatus == -1) {
                        sButton = `<a href="#" class="theme-btn-min theme-btn-primary">Cancelled</a>`;
                    } else if (pOrder.nStatus == 1) {
                        sButton = `<a href="#" class="theme-btn-min theme-btn-primary">Completed</a>`;
                    }
                    var sPickUp = new Date(pOrder.tPickUp).toLocaleString();
                    if (pOrder.bPDF) {
                        sPickUp = "PDF";
                    }
                    aData.rows.push([pOrder.nOrderID, pOrder.sBookName, '$' + pOrder.nTotalCostDue, sPickUp, sButton]);
                    aData.objects.push(pOrder);
                });
            }
            
            pOut.json(aData);
        });
    },

    //---------------------------------------------------------------------------------------------

    sendCourseData : function(sCourseID, pOut) {

        pOut.json({});
    },

    sendCourseList : function(pOut) {

        Course.prototype.getAll(function(aCourse) {

            const aData = {
                headers: ["Course ID", "Course Name", ""],
                rows: new Array(),
            }
            if (aCourse != null) {
                aCourse.forEach(pCourse => {
                    var sButton = `<a href="/store/${pCourse.sCourseID}" class="theme-btn theme-btn-primary">Browse Books</a>`;
                    aData.rows.push([pCourse.sCourseID, pCourse.sName, sButton]);
                });
            }
            
            pOut.json(aData);
        });
    },

}

//---------------------------------------------------------------------------------------------