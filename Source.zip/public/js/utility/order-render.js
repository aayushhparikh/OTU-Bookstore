{
    /**
     * Populate a table with data and render it to the page.
     * @param {HTML <div> Element} root 
     */
    async function updateOrder(root) {

        const pCollection = root.querySelector(".card-refresh__table");
        const pRes = await fetch(root.dataset.url);
        const pData = await pRes.json();

        // Reset Collection
        pCollection.innerHTML = `<div class="row"></div>`;

        const sEmail = document.querySelector(".card-refresh").id;
        const pBookData = document.querySelector(".book-data"); 
        const pBookButton = document.querySelector(".book-button"); 

        for (const pBook of pData.objects) {

            var bPDF = pBook.nAvailabilityType == 1;

            var nSubTotal = pBook.nCost;
            var nHST = pBook.nCost * 0.13;
            var nTotal = nSubTotal + nHST;

            pBookData.innerHTML = `
                    <div class="col-lg-2"></div>
                    <div class="col-lg-4">
                        <p class="col theme-form-label"><strong>Book</strong>: ${pBook.sName}</label>
                        <p class="col theme-form-label"><strong>Authors</strong>: ${pBook.sAuthors}</label>
                        <p class="col theme-form-label"><strong>Assosciated Course</strong>: ${pBook.sCourseID}</label>
                        <p class="col theme-form-label"><strong>Deliverable</strong>: ${bPDF ? ("PDF Sent to " + sEmail) : ("Physical Copy")}</label>
                        <p class="col theme-form-label"></label>
                        <p class="col theme-form-label"><strong>Sub Total</strong>: CA$${nSubTotal.toFixed(2)}</label>
                        <p class="col theme-form-label"><strong>HST (13%)</strong>: CA$${nHST.toFixed(2)}</label>
                        <p class="col theme-form-label"><strong>Total</strong>: CA$${nTotal.toFixed(2)}</label>
                    </div>
                    <div class="col-lg-4">
                        <div style="row">
                            <div class="col-lg-6">
                                <div class="">
                                    <img src="/images/books/${pBook.sCourseID}.png" width="300" class="theme-book-order">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2"></div>
                </div>
                
            `;

            if (bPDF) {
                document.querySelector(".static-alert").innerHTML = `Your PDF document will be sent to your email within 30 minutes of placing the order. 
                If you change your mind within this time, you may cancel the order on your dashboard or orders page.<br><br>
                Once your order is delivered, the total cost of the order will be automatically added to your tuition.<br><br>

                <strong>How Are We Helping?</strong><br>
                The university has taken the responsibility of ensuring all areas are frequently sanitized while only allowing those who have taken the COVID-19 Pre-Screening test to enter buildings on campus.
                In addition, to simplify the purchase process and limit physical contact, the cost of all orders are added directly to the students tuition providing the student with more time to make a payment.`;
            } else {
                document.querySelector(".static-alert").innerHTML = `Please select a time between 9:00 AM and 5:00 PM to come pick up your physical copy from the university bookstore.
                If you change your mind before the pick up time, you may cancel the order on your dashboard or orders page.<br><br>
                Once your order has been picked up, the total cost of the order will be automatically added to your tuition.<br><br>
                <strong>COVID-19 Safety Protocols & Measures</strong><br>
                During these difficult times we ask that everyone follows the restrictions and guidelines placed on the campus for the safety of all students and faculty.
                Be sure to take the COVID-19 Pre-Screening Test before coming to campus to pick up your order. While on campus we kindly ask that you do your best to keep a
                six feet distance from others when possible and wear your ask at all times.<br><br>

                <strong>How Are We Helping?</strong><br>
                The university has taken the responsibility of ensuring all areas are frequently sanitized while only allowing those who have taken the COVID-19 Pre-Screening test to enter buildings on campus.
                In addition, to simplify the purchase process and limit physical contact, the cost of all orders are added directly to the students tuition providing the student with more time to make a payment.
                `;
            }

            if (bPDF) {
                document.querySelector(".pickup").classList.add("hide");
            }

            pBookButton.innerHTML = `
                Order CA$${nTotal.toFixed(2)}
            `;
                        
        }
    }

    // Render Elements
    for (const root of document.querySelectorAll(".card-refresh[data-url]")) {
        
        const pCollection = document.createElement("div");
        pCollection.classList.add("card-refresh__table");
        document.querySelector(".card-refresh").append(pCollection);

        updateOrder(root);
    }

    var $j = jQuery.noConflict();
    $j(document).ready(function () {
        $j('#datepicker').datetimepicker({
            defaultDate: new Date(),
            format: "YYYY-MM-DD HH:mm:ss",
        });
    });
}