{
    /**
     * Populate a table with data and render it to the page.
     * @param {HTML <div> Element} root 
     */
    async function updateCollection(root) {

        const pCollection = root.querySelector(".card-refresh__table");
        const pRes = await fetch(root.dataset.url);
        const pData = await pRes.json();

        // Start Refresh Animation
        root.querySelector(".card-refresh__button").classList.add("card-refresh__button--refreshing");

        // Reset Collection
        pCollection.innerHTML = `<div class="row"></div>`;

        const pRow = pCollection.querySelector(".row"); 

        // Populate Collection 
        for (const pBook of pData.objects) {
            const pCard = document.createElement("div");

            pCard.id = pBook.nBookID;
            pCard.classList.add("col-md-3");
            pCard.classList.add("product-grid");

            var bPDF = pBook.nAvailabilityType == 1;
            var bOutOfStock = !bPDF && pBook.nStock <= 0;

            pCard.innerHTML = `
                <div class="image theme-book">
                    <img src="/images/books/${pBook.sCourseID}.png" class="w-100">
                </div>
                <h5 class="text-center book-name">${pBook.sName}</h5>
                <h5 class="text-center book-authors">By ${pBook.sAuthors}</h5>
                <h5 class="text-center book-stock">${bPDF ? ("PDF") : ("Physical Stock: " + pBook.nStock)}</h5>
                ${bOutOfStock ? `<a href="#" class="btn buy">Out of Stock</a>` : `<a href="/store/order/new/${pBook.nBookID}" class="btn buy">Order CA$${pBook.nCost.toFixed(2)}</a>`}
            `;
            pRow.appendChild(pCard);
        }

        // Refresh Last Update
        root.querySelector(".card-refresh__label").innerHTML = `Last Updated: ${ new Date().toLocaleString() }`;

        // Stop Refresh Animation
        root.querySelector(".card-refresh__button").classList.remove("card-refresh__button--refreshing");
    }

    // Render Table Elements
    for (const root of document.querySelectorAll(".card-refresh[data-url]")) {
        
        const pCollection = document.createElement("div");
        const pOptions = document.createElement("div");

        pCollection.classList.add("card-refresh__table");
        pOptions.classList.add("card-refresh__options");

        pOptions.innerHTML = `
            <span class="card-refresh__label">Last Updated: Never</span>
            <button type="button" class="card-refresh__button">
                <i class="material-icons">refresh</i>
            </button>
        `;

        document.querySelector(".card-refresh").append(pCollection, pOptions);

        pOptions.querySelector(".card-refresh__button").addEventListener("click", () => {
            updateCollection(root);
        });

        updateCollection(root);
    }
}