{
    /**
     * Populate a table with data and render it to the page.
     * @param {HTML <div> Element} root 
     */
    async function updateTable(root) {

        const pTable = root.querySelector(".table-refresh__table");
        const pRes = await fetch(root.dataset.url);
        const pData = await pRes.json();

        // Start Refresh Animation
        root.querySelector(".table-refresh__button").classList.add("table-refresh__button--refreshing");

        // Clear Table
        pTable.querySelector("thead tr").innerHTML = ``;
        pTable.querySelector("tbody").innerHTML = ``;

        // Populate Table Headers
        for (const pHeader of pData.headers) {
            pTable.querySelector("thead tr").insertAdjacentHTML("beforeend", `<th>${ pHeader }</th>`);
        }

        // Populate Table Headers
        for (const pRow of pData.rows) {
            pTable.querySelector("tbody").insertAdjacentHTML("beforeend", `
                <tr>
                    ${ pRow.map(pCol => `<td>${ pCol }</td>`).join("") }
                </tr>
            `);
        }

        // Refresh Last Update
        root.querySelector(".table-refresh__label").innerHTML = `Last Updated: ${ new Date().toLocaleString() }`;

        // Stop Refresh Animation
        root.querySelector(".table-refresh__button").classList.remove("table-refresh__button--refreshing");
    }

    // Render Table Elements
    for (const root of document.querySelectorAll(".info-refresh[data-url]")) {
        
        const pTable = document.createElement("table");
        const pOptions = document.createElement("div");

        pTable.classList.add("table-refresh__table");
        pOptions.classList.add("table-refresh__options");

        pTable.innerHTML = `
            <thead>
                <tr><tr>
            </thead>
            <tbody>
                <tr>
                    <td>Loading</td>
                </tr>
            </tbody>
        `;

        pOptions.innerHTML = `
            <span class="table-refresh__label">Last Updated: Never</span>
            <button type="button" class="table-refresh__button">
                <i class="material-icons">refresh</i>
            </button>
        `;

        document.querySelector(".info-refresh").append(pTable, pOptions);

        pOptions.querySelector(".table-refresh__button").addEventListener("click", () => {
            updateTable(root);
        });

        updateTable(root);
    }
}

{
    // Render Table Elements
    for (const root of document.querySelectorAll(".course-refresh[data-url]")) {
        
        const pTable = document.createElement("table");
        const pOptions = document.createElement("div");

        pTable.classList.add("table-refresh__table");
        pOptions.classList.add("table-refresh__options");

        pTable.innerHTML = `
            <thead>
                <tr><tr>
            </thead>
            <tbody>
                <tr>
                    <td>Loading</td>
                </tr>
            </tbody>
        `;

        pOptions.innerHTML = `
            <span class="table-refresh__label">Last Updated: Never</span>
            <button type="button" class="table-refresh__button">
                <i class="material-icons">refresh</i>
            </button>
        `;

        document.querySelector(".course-refresh").append(pTable, pOptions);

        pOptions.querySelector(".table-refresh__button").addEventListener("click", () => {
            updateOrders(root);
        });

        updateOrders(root);
    }
}