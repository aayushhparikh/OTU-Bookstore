const Express = require('express');
const Router = Express.Router();
const Passport = require('passport');
const User = require('../core/models/User');
const { enforceAuth, rejectAuth } = require('../core/authentication.js');

//---------------------------------------------------------------------------------------------

// Login View
Router.get('/login', rejectAuth, (pReq, pRes) => pRes.render("Login"));

// Register View
Router.get('/register', rejectAuth, (pReq, pRes) => pRes.render("Register"));

//---------------------------------------------------------------------------------------------

/**
 * Handle user login requests.
 */
Router.post('/login', (pReq, pRes, Next) => {
    Passport.authenticate('local', {
        successRedirect: '/dashboard',
        failureRedirect: '/auth/login',
        failureFlash: true
    })(pReq, pRes, Next);
});

/**
 * Handle user logout requests.
 */
Router.get('/logout', (pReq, pRes) => {
    pReq.logout();
    pReq.flash('SuccessMessage', 'You have logged out successfully.');
    pRes.redirect('/auth/login');
});

/**
 * Handle user registration requests.
 */
Router.post('/register', (pReq, pRes) => {

    const { email, password, password2 } = pReq.body;
    let errors = [];

    // Check Required Fields
    if (!email || !password || !password2) {
        errors.push( { msg: 'Please ensure all fields are filled out correctly.' });
    }

    // Confirm Passwords Match
    if (password != password2) {
        errors.push( { msg: 'Please ensure both password fields match.' });
    }

    // Check Password Length
    if (password.length < 6) {
        errors.push( { msg: 'Your password must be at least 6 characters in length.' });
    }

    // Check University Email
    if (!email.includes("@ontariotechu.") && !email.includes("@uoit.")) {
        errors.push( { msg: 'Please ensure you are signing up using your provided ontariotechu.net email address.' });
    }

    if (errors.length > 0) {
        pRes.render('Register', { errors, email });
    } else {

        // Check If Email Exists
        User.prototype.emailExists(email, function(exists) {
            if (exists) {
                errors.push( { msg: 'Sorry, an account already exists with that email address.' });
                pRes.render('Register', { errors, email, password, password2 });
            } else {
                User.prototype.register(email, password);
                pReq.flash('SuccessMessage', 'You have successfully registered and may now login.');
                pRes.redirect('/auth/login');
            }
        });
    }
});

//---------------------------------------------------------------------------------------------

module.exports = Router;

//---------------------------------------------------------------------------------------------