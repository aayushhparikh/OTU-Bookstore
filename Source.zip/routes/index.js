const Express = require('express');
const Router = Express.Router();
const { enforceAuth, rejectAuth } = require('../core/authentication.js');
const Book = require('../core/models/Book.js');
const Order = require('../core/models/Order.js');

//---------------------------------------------------------------------------------------------

Router.get('/', rejectAuth, (pReq, pRes) => pRes.render('Home'));

Router.get('/dashboard', enforceAuth, (pReq, pRes) => {
    pRes.render('Dashboard', { name: pReq.user.sFirstName, studentID: pReq.user.nStudentID });
});

Router.get('/courses', enforceAuth, (pReq, pRes) => {
    pRes.render('Courses', { user: pReq.user });
});

//---------------------------------------------------------------------------------------------

Router.get('/store', enforceAuth, (pReq, pRes) => {
    pRes.render('Store', { user: pReq.user, search: "", course: 'all' });
});

Router.get('/store/:id', enforceAuth, (pReq, pRes) => {
    var sCourseID = pReq.params.id;
    pRes.render('Store', { user: pReq.user, search: "", course: 'course/' + sCourseID });
});

Router.get('/enrolled/', enforceAuth, (pReq, pRes) => {
    pRes.render('Store', { user: pReq.user, search: "", course: 'user'});
});

Router.post('/search', enforceAuth, (pReq, pRes) => {
    const { search } = pReq.body;
    pRes.render('Store', { user: pReq.user, search: " | Search Results for '" + search + "'", course: 'search/' + search});
});

Router.get('/store/order/new/:id', enforceAuth, (pReq, pRes) => {
    var nBookID = pReq.params.id;
    Book.prototype.find(nBookID, function(pBook) {
        if (pBook != null) {
            pRes.render('Checkout', { user: pReq.user, book: pBook });
        } else {
            pRes.redirect('/store');
        }
    });
});

Router.post('/store/order/new/:id/submit', enforceAuth, (pReq, pRes) => {

    var nBookID = pReq.params.id;
    Book.prototype.find(nBookID, function(pBook) {
        if (pBook != null) {
            const { date } = pReq.body;
            let errors = [];

            var pDate = new Date(Date.parse(date));
            var bPDF = pBook.nAvailabilityType == 1;

            if (!bPDF && (pDate.getHours() < 9 || pDate.getHours() >= 17)) {
                errors.push({ msg: 'Please select a time between 9:00 AM and 5:00 PM (09:00 - 18:00).' })
            }

            if (errors.length > 0) {
                pRes.render('Checkout', { errors, user: pReq.user, book: pBook });
            } else {

                var pOrder = new Order();
                pOrder.nStudentID = pReq.user.nStudentID;
                pOrder.nBookID = pBook.nBookID;
                pOrder.nQuantity = 1;
                pOrder.nTotalCostDue = pBook.nCost;
                pOrder.tPickUp = date;
                pOrder.nStatus = 0;

                pReq.user.placeOrder(pOrder);
                pReq.flash('SuccessMessage', 'You have successfully placed an order.');
                pRes.redirect('/dashboard');
                
            }
        } else {
            pRes.redirect('/store');
        }
    });
    
});

Router.get('/store/order/cancel/:id', enforceAuth, (pReq, pRes) => {
    var nOrderID = pReq.params.id;
    Order.prototype.find(nOrderID, function(pOrder) {
        if (pOrder != null) {
            pReq.user.cancelOrder(pOrder);
            pReq.flash('SuccessMessage', 'You have successfully cancelled the order.');
            pRes.redirect('/dashboard');
        } else {
            pRes.redirect('/dashboard');
        }
    });
});

//---------------------------------------------------------------------------------------------

Router.get('/orders', enforceAuth, (pReq, pRes) => {
    pRes.render('Orders', { user: pReq.user });
});

//---------------------------------------------------------------------------------------------

module.exports = Router;

//---------------------------------------------------------------------------------------------