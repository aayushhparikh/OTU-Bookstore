const Express = require('express');
const Router = Express.Router();
const API = require('../core/api.js');
const { enforceAuth, rejectAuth } = require('../core/authentication.js');

//---------------------------------------------------------------------------------------------

Router.get('/course/user', enforceAuth, (pReq, pRes) => {
    API.sendUserEnrollmentData(pReq.user.nStudentID, pRes);
});
Router.get('/course/user/:id', enforceAuth, (pReq, pRes) => {
    var nStudentID = pReq.params.id;
    API.sendUserEnrollmentData(nStudentID, pRes);
});

Router.get('/course/all', (pReq, pRes) => {
    API.sendCourseList(pRes);
});

//---------------------------------------------------------------------------------------------

Router.get('/book/course/:id', (pReq, pRes) => {
    var sCourseID = pReq.params.id;
    API.sendCourseBookList(sCourseID, pRes);
});

Router.get('/book/all', (pReq, pRes) => {
    API.sendBookList(pRes);
});

Router.get('/book/user/', enforceAuth, (pReq, pRes) => {
    API.sendEnrolledBookList(pReq.user.nStudentID, pRes);
});

Router.get('/book/search/:search', enforceAuth, (pReq, pRes) => {
    var sSearch = pReq.params.search;
    API.sendBookSearch(sSearch, pRes);
});

//---------------------------------------------------------------------------------------------

Router.get('/order/user', enforceAuth, (pReq, pRes) => {
    API.sendOrders(pReq.user.nStudentID, true, true, pRes);
});

Router.get('/order/user/active', enforceAuth, (pReq, pRes) => {
    API.sendOrders(pReq.user.nStudentID, true, false, pRes);
});
Router.get('/order/user/active/:id', enforceAuth, (pReq, pRes) => {
    var nStudentID = pReq.params.id;
    API.sendOrders(nStudentID, true, false, pRes);
});

Router.get('/order/user/archived', enforceAuth, (pReq, pRes) => {
    API.sendOrders(pReq.user.nStudentID, false, true, pRes);
});
Router.get('/order/user/archived/:id', enforceAuth, (pReq, pRes) => {
    var nStudentID = pReq.params.id;
    API.sendOrders(nStudentID, false, true, pRes);
});

Router.get('/order/admin/active', enforceAuth, (pReq, pRes) => {
    API.sendManageOrders(-1, true, false, pRes);
});
Router.get('/order/admin/active/:id', enforceAuth, (pReq, pRes) => {
    var nStudentID = pReq.params.id;
    API.sendManageOrders(nStudentID, true, false, pRes);
});

Router.get('/order/admin/archived', enforceAuth, (pReq, pRes) => {
    API.sendManageOrders(-1, false, true, pRes);
});
Router.get('/order/admin/archived/:id', enforceAuth, (pReq, pRes) => {
    var nStudentID = pReq.params.id;
    API.sendManageOrders(nStudentID, false, true, pRes);
});

//---------------------------------------------------------------------------------------------

Router.get('/user/data/:email', (pReq, pRes) => {
    var sEmail = pReq.params.email;
    API.sendUserData(sEmail, pRes);
});

Router.get('/book/data/:id', (pReq, pRes) => {
    var nBookID = pReq.params.id;
    API.sendBookData(nBookID, pRes);
});

Router.get('/course/data/:id', (pReq, pRes) => {
    var sCourseID = pReq.params.id;
    API.sendCourseData(sCourseID, pRes);
});

//---------------------------------------------------------------------------------------------

module.exports = Router;

//---------------------------------------------------------------------------------------------