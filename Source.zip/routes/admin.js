const Express = require('express');
const Router = Express.Router();
const { enforceAuth, rejectAuth } = require('../core/authentication.js');
const Book = require('../core/models/Book.js');
const Order = require('../core/models/Order.js');
const User = require('../core/models/User.js');

//---------------------------------------------------------------------------------------------

Router.get('/', enforceAuth, (pReq, pRes) => {
    pRes.render('Admin', { user: pReq.user });
});

Router.post('/user/search', enforceAuth, (pReq, pRes) => {
    var { search } = pReq.body;
    if (search == '') search = '-';
    pRes.render('Profile', { user: pReq.user, search_id: search, search: " | Results for '" + search + "'", course: 'search/' + search});
});

//---------------------------------------------------------------------------------------------

Router.get('/order/cancel/:id', enforceAuth, (pReq, pRes) => {
    var nOrderID = pReq.params.id;
    Order.prototype.find(nOrderID, function(pOrder) {
        if (pOrder != null) {
            User.prototype.cancelOrder(pOrder);
            pReq.flash('SuccessMessage', 'You have successfully cancelled the order.');
            pRes.redirect('/admin');
        } else {
            pRes.redirect('/admin');
        }
    });
});

Router.get('/order/confirm/:id', enforceAuth, (pReq, pRes) => {
    var nOrderID = pReq.params.id;
    Order.prototype.find(nOrderID, function(pOrder) {
        if (pOrder != null) {
            User.prototype.confirmOrder(pOrder);
            pReq.flash('SuccessMessage', 'You have successfully confirmed the order.');
            pRes.redirect('/admin');
        } else {
            pRes.redirect('/admin');
        }
    });
});

//---------------------------------------------------------------------------------------------

module.exports = Router;

//---------------------------------------------------------------------------------------------