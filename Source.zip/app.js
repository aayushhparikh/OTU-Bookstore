/**
 * OntarioTechU Bookstore
 */

//
global.__basedir = __dirname;

// Load Environment Configuration
require('dotenv').config();

//---------------------------------------------------------------------------------------------

// Create Express Instance
const Express = require('express');
const pApp = Express();

// Enable Public Directory
pApp.use(Express.static(__dirname + '/public'));

// Initialize EJS Configuration
const ExpressLayouts = require('express-ejs-layouts');
pApp.use(ExpressLayouts);
pApp.set('view engine', 'ejs');

// Body Parser
pApp.use(Express.urlencoded({ extended: false }));

//---------------------------------------------------------------------------------------------

// Express Session
const ExpressSession = require('express-session');

// Session Storage
const MySQLStore = require('express-mysql-session');

const DATABASE_HOST='localhost';
const DATABASE_PORT=8889;
const DATABASE_USER='root';
const DATABASE_PASSWORD='root';
const DATABASE_SCHEMA='ontechu_bookstore';

const pMySQL_Options = {
    host: DATABASE_HOST,
    port: DATABASE_PORT,
    user: DATABASE_USER, 
    password: DATABASE_PASSWORD, 
    database: DATABASE_SCHEMA
};
const pSessionStore = new MySQLStore(pMySQL_Options);

// Initialize Express Session
pApp.use(ExpressSession({ secret: 'otubooks', resave: true, store: pSessionStore, saveUninitialized: true }));

//---------------------------------------------------------------------------------------------

// Authentication Passport
const Passport = require('passport');
require('./core/passport.js')(Passport);

// Initialize Passport
pApp.use(Passport.initialize());
pApp.use(Passport.session());

//---------------------------------------------------------------------------------------------

// Connect Flash
const Flash = require('connect-flash');
pApp.use(Flash());

// Global Vars
pApp.use((pReq, pRes, pNext) => {
    pRes.locals.SuccessMessage = pReq.flash('SuccessMessage');
    pRes.locals.ErrorMessage = pReq.flash('ErrorMessage');
    pRes.locals.Error = pReq.flash('error');
    pNext();
});

var pAllowCrossDomain = function(pReq, pRes, pNext) {
    pRes.header('Access-Control-Allow-Origin', "*");
    pRes.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    pRes.header('Access-Control-Allow-Headers', 'Content-Type');
    pNext();
}

pApp.use(pAllowCrossDomain);

//---------------------------------------------------------------------------------------------

// Define EJS View Routes
pApp.use('/', require('./routes/index'));
pApp.use('/admin', require('./routes/admin'));
pApp.use('/auth', require('./routes/auth'));
pApp.use('/api', require('./routes/api'));
pApp.get('/', function(pReq, pRes){
    pRes.render("index");
});

process.on('uncaughtException', function (err) {
    console.log(err);
}); 

//---------------------------------------------------------------------------------------------

// Start Web Server
var nPort = process.env.PORT || 3000;
pApp.listen(nPort, console.log(" -> Starting Web Server on Port (" + nPort + ")"));

//---------------------------------------------------------------------------------------------